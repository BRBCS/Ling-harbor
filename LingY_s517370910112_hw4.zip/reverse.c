#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(void)
{
	int i, len;
	char num[40];
	char num2[40];

	printf("Please enter a positive integer:");
	scanf("%s", num);
	len = strlen(num);
	for (i = 0; i < len; i++)
	{
		num2[len - i - 1] = num[i];
	}
	num2[len] = '\0';
	printf("The reversed number is %s\n", num2);
	system("pause");

	return 0;
}