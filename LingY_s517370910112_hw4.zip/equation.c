#include<stdio.h>
#include<math.h>
#include<stdlib.h>

int main(void)
{
	double a, b, c, x_1, x_2, x_1_ima, delta;

	printf("a=");
	scanf("%lf", &a);
	printf("b=");
	scanf("%lf", &b);
	printf("c=");
	scanf("%lf", &c);
		if (a == 0)
		{
			if (b == 0)
			{
				if (c == 0)
				{
					printf("The equation has no solution.\n");
				}
				else
				{
					x_1 = 0;
					printf("The only solution is %lf\n", x_1);
				}
			}
			else
			{
				x_1 = (-c) / b;
				printf("The only solution is %lf\n", x_1);
			}
		}
		else
		{
			delta = b*b - 4 * a*c;
			if (delta > 0)
			{
				x_1 = (-b + sqrt(delta)) / (2 * a);
				x_2 = (-b - sqrt(delta)) / (2 * a);
				printf("The first solution is %lf\n", x_1);
				printf("The second solution is %lf\n", x_2);
			}
			else if (delta == 0)
			{
				x_1 = (-b) / (2 * a);
				printf("The only solution is %lf\n", x_1);
			}
			else
			{
				x_1 = (-b) / (2 * a);
				x_1_ima = sqrt(-delta)/(2*a);
				printf("The first solution is %lf+%lfi\n", x_1, x_1_ima);
				printf("The second solution is %lf-%lfi\n", x_1, x_1_ima);
			}

		}
		system("pause");

		return 0;
	}
