#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	double T;
	printf("Fahrenheit temperature?");
	scanf("%lf", &T);
	T = (T - 32) / 1.8;
	printf("Celsius equivalent:%lf\n", T);

	system("pause");
	return 0;
}